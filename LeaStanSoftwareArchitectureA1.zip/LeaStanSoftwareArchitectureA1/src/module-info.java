/**
 * 
 */
/**
 * 
 */
module LeaStanSoftwareArchitectureA1 {
}